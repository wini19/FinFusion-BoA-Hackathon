import React from 'react';
import { FaInfoCircle } from 'react-icons/fa';

const RefactorAssistant = ({ selectedApi }) => {
  const suggestions = [
    { title: 'Combine Endpoints', description: 'Merge similar endpoints to reduce redundancy and improve maintainability.' },
    { title: 'Improve Naming', description: 'Use consistent naming conventions across all APIs for better clarity.' },
    { title: 'Add Pagination', description: 'Implement pagination for large data sets to optimize performance.' },
    { title: 'Enhance Security', description: 'Apply OAuth2 and validate input to prevent security vulnerabilities.' }
  ];

  const similarityData = selectedApi
    ? {
        apiName: selectedApi.owningService,
        duplicates: [
          { name: 'User Profile API', score: 78 },
          { name: 'Auth Service API', score: 72 },
          { name: 'Session Manager API', score: 65 }
        ]
      }
    : null;

  return (
    <div>
      {/* Similarity Analysis Card */}
      <div className="similarity-card standout">
        <div className="similarity-header">
          <h4>🔍 Similarity Analysis</h4>
          <FaInfoCircle className="info-icon" />
        </div>
        {!selectedApi ? (
          <div className="info-message">
            <span>Click on an API in the heatmap to view similar APIs.</span>
          </div>
        ) : (
          <div className="similarity-results">
            <p><strong>Similarity Check Results:</strong></p>
            <div className="similarity-grid">
              {similarityData.duplicates.map((dup, index) => (
                <div key={index} className="similarity-item">
                  <h5>{dup.name} vs {dup.name}</h5>
                  <div className={`score-badge ${dup.score >= 75 ? 'high' : dup.score >= 50 ? 'medium' : 'low'}`}>
                    {dup.score}% Similar
                  </div>
                  <div className="progress-bar">
                    <div style={{ width: `${dup.score}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* API Refactor Assistant */}
      <h2>API Refactor Assistant</h2>
      <div className="suggestions-container">
        <h3>Refactor Suggestions</h3>
        <div className="suggestion-cards">
          {suggestions.map((item, index) => (
            <div key={index} className="suggestion-card">
              <h4>{item.title}</h4>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RefactorAssistant;
