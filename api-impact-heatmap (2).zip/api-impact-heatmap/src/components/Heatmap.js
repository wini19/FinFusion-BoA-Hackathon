import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import data from '../domain/HeatMapUsageApi.json';

const Heatmap = ({ onApiClick }) => {
  const svgRef = useRef();

  useEffect(() => {
    const columns = 5
    ; // Number of columns in the grid
    data.forEach((d, i) => {
      d.x = i % columns;
      d.y = Math.floor(i / columns);
    });

    const cellSize = 120;
    const width = columns * cellSize;
    const height = Math.ceil(data.length / columns) * cellSize;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .style('font-family', 'Arial');

      const colorScale = d3.scaleSequential(d3.interpolateRdYlGn)
      .domain([0, d3.max(data, d => d.impactScore)]); // Low = Red, High = Green

    // Tooltip (Flyout)
    const flyout = d3.select('body').append('div')
      .attr('class', 'flyout')
      .style('position', 'absolute')
      .style('visibility', 'hidden')
      .style('background', '#fff')
      .style('color', '#333')
      .style('padding', '10px 15px')
      .style('border', '1px solid #ccc')
      .style('border-radius', '6px')
      .style('box-shadow', '0 4px 8px rgba(0,0,0,0.1)')
      .style('pointer-events', 'none')
      .style('font-size', '14px');

    const cells = svg.selectAll('g')
      .data(data)
      .join('g')
      .attr('transform', d => `translate(${d.x * cellSize}, ${d.y * cellSize})`);

    // Rounded rectangles
    cells.append('rect')
      .attr('width', cellSize - 10)
      .attr('height', cellSize - 10)
      .attr('rx', 12)
      .attr('ry', 12)
      .attr('fill', d => colorScale(d.impactScore))
      .attr('tabindex', 0)
      .attr('aria-label', d => `API ${d.owningService}, Impact ${d.impactScore}`)
      .on('mouseover', (event, d) => {
        flyout.html(`
          <strong>${d.owningService}</strong><br/>
          Calls: ${d.calls}<br/>
          Consumers: ${d.consumers}<br/>
          Impact Score: ${d.impactScore}
        `)
        .style('visibility', 'visible')
        .style('opacity', 1);
        d3.select(event.currentTarget)
          .style('stroke', '#000')
          .style('stroke-width', '2px');
      })
      .on('mousemove', (event) => {
        flyout.style('top', (event.pageY + 10) + 'px')
              .style('left', (event.pageX + 10) + 'px');
      })
      .on('mouseout', (event) => {
        flyout.style('visibility', 'hidden').style('opacity', 0);
        d3.select(event.currentTarget)
          .style('stroke', 'none');
      })
      .on('click', (event, d) => {
        onApiClick(d); // Pass clicked API data to parent
      });

    // Add wrapped text labels inside cells (centered)
    cells.append('text')
      .attr('text-anchor', 'middle')
      .attr('fill', 'black') // Changed to black
      .style('font-size', '14px')
      .style('font-weight', 'bold')
      .each(function(d) {
        console.log('d', d)
        const words = d.owningService.split(' ');
        const maxCharsPerLine = 10;
        let line = '';
        const lines = [];

        words.forEach(word => {
          if ((line + word).length > maxCharsPerLine) {
            lines.push(line.trim());
            line = word + ' ';
          } else {
            line += word + ' ';
          }
        });
        if (line) lines.push(line.trim());

        const textElement = d3.select(this);
        const totalHeight = lines.length * 16; // lineHeight = 16px
        const startY = ((cellSize - 10) / 2) - (totalHeight / 2); // Center vertically

        lines.forEach((l, i) => {
          textElement.append('tspan')
            .attr('x', (cellSize - 10) / 2)
            .attr('y', startY + i * 16)
            .text(l);
        });
      });
  }, []);

  return <svg ref={svgRef}></svg>;
};

export default Heatmap;
